public class Employee implements Displayable, DepartmentConstants
{
    private int department;
    private String firstName;
    private String lastName;
    private double salary;

    public Employee(int department, String lastName, String firstName,
        double salary)
    {
        this.department = department;
        this.lastName = lastName;
        this.firstName = firstName;
        this.salary = salary;
    }
    
             
        public String getDisplayText(String display_str){
         display_str = "Department: " + DepartmentConstants.names[this.department - 1] + "\n" +
           "FirstName: " + this.firstName + "\tLastName: " + this.lastName +"\n" +
           "Salary: " + this.salary + "\n"; 
         
         return display_str; 
                   
        }
}