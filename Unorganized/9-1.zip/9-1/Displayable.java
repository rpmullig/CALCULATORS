public interface Displayable {

  public String getDisplayText(String display_str);
  
}