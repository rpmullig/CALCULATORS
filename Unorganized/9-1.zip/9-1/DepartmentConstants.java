public interface DepartmentConstants {
  
 final int ADMIN = 1;
 final int EDITORIAL = 2; 
 final int MARKETING = 3; 
 // page 283 for other interface variable constants
 
 final String[] names = { "ADMIN", "EDITORIAL", "MARKETING" }; 

}