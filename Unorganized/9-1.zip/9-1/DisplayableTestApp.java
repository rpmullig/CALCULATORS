public class DisplayableTestApp
{
    public static void main(String args[])
    {
        System.out.println("Welcome to the Displayable Test application\n");

        // create an Employee object
        Employee emp = new Employee(01,"Mulligan","Robert",1040000000); 
        
        // display the employee information
        displayMultiple(emp, 2); 
        
        // create a Product objects
        Product product = new Product("444444","This is a random product that some people buy N' stuff", 10.89);
        Product product_1 = new Product("555555","An expensive product", 100.00);
        Product product_2 = new Product("66666666","a cheap product", 1.75);
        Product product_3 = new Product("7777777","PlayStation4", 299.99);
        

        // display the product information     
        displayMultiple(product, 2); 
        displayMultiple(product_1, 2); 
        displayMultiple(product_2, 2); 
        displayMultiple(product_3, 2); 
        
    }//END OF MAIN METHOD

        
        private static void displayMultiple(Displayable d, int count) {
          
          for (int x = 0; x<count; x++) {
            System.out.println("+------------------------------------+");
            System.out.println(d.getDisplayText(""));
            System.out.println("Count: " + (x+1)); 
            System.out.println("+------------------------------------+");        
          }//END OF FOR LOOP
          
        }//END OF METHOD DISPLAYMULTIPLE
}