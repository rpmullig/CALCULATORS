import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rpmullig
 */
public class pizza {
    
    
    private int size;
    boolean [] toppings = {false, false, false, false, false, false};
    

    private double[] size_cost =  {6.99,8.99,10.99};
    private double[] topping_cost = {1.49,1.49,1.49,0.99,0.99,0.99};
    
    private double price = 0.0; 
    
    

    pizza() {}
    
    public void setSize(int s){ this.size=s;}

    public int getSize(int s){ return this.size;} 
    
    public void setTopping(int i) {this.toppings[i] = true; }
    
    public void removeTopping(int i) {this.toppings[i] = false; }
    
    public float getPrice(){
        return (float) this.price;
    }
    
    public void setPrice() {
        
        
        this.price = 0; 
        
        this.price += size_cost[this.size];
        
        for(int i = 0 ; i < 6; i++){
            if(this.toppings[i]){
                
                this.price += topping_cost[i];  
            }
            
        }   
    }
   
    
}
