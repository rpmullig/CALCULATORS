import java.text.NumberFormat;

class Invoice {
  private String customer_type; 
  private double subtotal;
  private double discountPercent; 
  
   public Invoice(String __customer_type, double __subtotal){
     setCustomerType(__customer_type);
     this.subtotal =  __subtotal;   
  }
   
  double getSubtotal(){
    return this.subtotal; 
  }
  
  
  double getDiscountPercent()
  {
    this.discountPercent = 0.0;
    
    if (this.customer_type.equalsIgnoreCase("Retail"))
    {if (this.subtotal >= 500)
      {this.discountPercent = .2;
      return .2;}
      else if (this.subtotal >= 250 && this.subtotal < 500)
      {this.discountPercent =.15;
        return .15;}
      else if (this.subtotal >= 100 && this.subtotal < 250)
      {this.discountPercent =.1;
        return .1;}
      else if (this.subtotal < 100)
      {this.discountPercent =.0;
        return .0; }
    }
    else if (this.customer_type.equalsIgnoreCase("College"))
    {this.discountPercent = .2;
    return .2; }
    
    else {this.discountPercent = .05;
    return .05; }
    
    
    return this.discountPercent;
  }
  
  double getDiscountAmount(){ 
      return ( this.subtotal * this.getDiscountPercent() ); 
  }
  
  double getTotal(){
    return ( this.subtotal - this.getDiscountAmount() );
  }
  

  void setCustomerType(String type){
   if (type.equalsIgnoreCase("r")) {this.customer_type = "Retail";}
   else if (type.equalsIgnoreCase("c")){this.customer_type = "College";}
   else{this.customer_type = "Unknown"; }
  }
   
   String getCustomerType(){
     return this.customer_type;
   }
  

  
}