import java.text.NumberFormat;
import java.util.Scanner;


public class InvoiceApp
{ 
  public static void main(String[] args)
  {
    // display a welcome message
    System.out.println("Welcome to the Invoice Total Calculator" + "\n");
       
    
    Scanner sc = new Scanner(System.in);
    String choice = "y";
    while(choice.equalsIgnoreCase("y"))
    {
      // get user entries
   String customerType = Validator.getString(sc,
                                    "Enter customer type (r/c):   ");
    double subtotal = Validator.getDouble(sc,
                                           "Enter subtotal:              ", 0, 10000);
      

      Invoice current_invoice = new Invoice(customerType, subtotal); 
            
      // format and display the results
      NumberFormat currency = NumberFormat.getCurrencyInstance();
      NumberFormat percent = NumberFormat.getPercentInstance();

      String subtotal_string = currency.format(current_invoice.getSubtotal());
      String customer_type_string = (current_invoice.getCustomerType());
      String Discount_string = currency.format(current_invoice.getDiscountAmount());
      String Discount_Percent_string = percent.format(current_invoice.getDiscountPercent());
      String Total_string = currency.format(current_invoice.getTotal());
      
      String message = 
        "Subtotal:         " + subtotal_string + "\n"
        + "Customer type:    " + customer_type_string + "\n"
        + "Discount percent: " + Discount_Percent_string + "\n"
        + "Discount amount:  " + Discount_string + "\n"
        + "Total:            " + Total_string + "\n";
      
      
      System.out.println("\n" + message);

      System.out.print("Continue? (y/n): ");
      choice = sc.next();
      System.out.println();
    }
  }
  
}