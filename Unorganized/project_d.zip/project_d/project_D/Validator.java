import java.util.Scanner; 

class Validator {
  
  public static String getString(Scanner sc){
    String s = "";
    boolean isValid = false;
    while (isValid == false)
    {
      if (sc.hasNext())
      {
        s = sc.next();
        isValid = true;
      }
      else
      {
        System.out.println("Error! Invalid value. Try again.");
      }
      sc.nextLine();  // discard any other data entered on the line
    } 
    return s;
  }
  

    public static String getChar(Scanner sc){
    String s = "";
    boolean isValid = false;
    while (isValid == false)
    {
      if (sc.hasNext())
      {
        s = sc.next();
        if(s.trim().length() == 1){
          isValid = true;
        }
        else { System.out.println("Try a single character only"); 
        }
      }
      else
      {
        System.out.println("Error! Invalid value. Try again.");
      }
      sc.nextLine();  // discard any other data entered on the line
    } 
    return s;
  }
  
  
  
}