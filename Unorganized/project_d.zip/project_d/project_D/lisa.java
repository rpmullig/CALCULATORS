public class lisa extends player {
  
  private Roshambo rsb; 
  
  public lisa() {
    super();
    super.setName("Lisa");   
  }
  
  
  public Roshambo generateRoshambo() {
        
    Roshambo[] Roshambos = Roshambo.values();
    int number = (int) ( Math.random()*10 % 3 ); 
        
    return Roshambos[number]; 
  }
  
}