import java.util.Scanner;

public class player1 extends player {
  
  private Roshambo rsb; 
  
  public player1() {
    super();
    super.setName("You");   
  }
  
  
  public Roshambo generateRoshambo() {
    
    Roshambo[] Roshambos = Roshambo.values();
    Scanner sc = new Scanner(System.in); 
    
    
    System.out.print("\nRock, paper, or scissors? (R/P/S):"); 
    String choice = Validator.getChar(sc);
    
    while(!(choice.equalsIgnoreCase("R") || choice.equalsIgnoreCase("P") || choice.equalsIgnoreCase("S")) ) { 
      
      System.out.print("\nChoices are rock, paper, or scissors. Please put a \'R\' \'S\' or \'P\'"); 
      choice = Validator.getChar(sc);
      
    }//while ends
   
    if(choice.equalsIgnoreCase("R")){rsb = Roshambo.ROCK; }
    else if(choice.equalsIgnoreCase("P")){rsb = Roshambo.PAPER; }
    else if(choice.equalsIgnoreCase("S")){rsb = Roshambo.SCISSORS; }

    return rsb; 
  }
  
}