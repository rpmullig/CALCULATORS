import java.util.Scanner;
import java.lang.Math;

public abstract class player {
  
  private String name; 
  private Roshambo rsb; 
  
  
  public player() {}
  
  void setName(String name) { this.name = name; }
 
  String getName() {return this.name; }
  
  public abstract Roshambo generateRoshambo();
    
   public void setRoshambo(Roshambo rsb){
     rsb = this.rsb; 
  }
  
   public Roshambo getRoshambo(){
    return rsb; 
  }  
}