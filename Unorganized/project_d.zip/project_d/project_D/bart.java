public class bart extends player {
  
  
  private Roshambo rsb; 
  
  public bart() {
    super();
    super.setName("Bart");   
  }
  
  
  public Roshambo generateRoshambo() {
    
    Roshambo[] Roshambos = Roshambo.values();    
    return Roshambos[1]; 
  }
  
  
}