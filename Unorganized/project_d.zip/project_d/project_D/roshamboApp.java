import java.util.Scanner;

public class roshamboApp {
  
  public static void main(String[] args){
    
    int wins = 0, losses = 0; 
    Scanner sc = new Scanner(System.in); 
    player1 user = new player1();
    
    // Just some variables I pulled out of the while loop for memory optimization
    String rival_choice_string, user_choice_string, output1, output2; 
    Roshambo rival_choice, user_choice;
    
    System.out.println("Welcome to the game of Roshambo");
    System.out.print("Enter your name: ");
    
    
    String name = Validator.getString(sc);  
    
    user.setName(name); 
    
    
    System.out.print("\nWould you like to play Bart or Lisa? (B/L):"); 
    
    String opponent = Validator.getChar(sc);
    
    while( !(opponent.equalsIgnoreCase("B") || opponent.equalsIgnoreCase("L"))  ) { 
      
      System.out.println("\nChoices are Bart or Lisa. Please put a \'B\' or \'L\'\n"); 
      opponent = Validator.getChar(sc);    
    }//while ends
    
    bart bart = new bart(); 
    lisa lisa = new lisa();
    player rival; 
    
    if(opponent.equalsIgnoreCase("B")) { rival = bart; }
    else { rival = lisa; }
    
    
    String input = "y"; 
    String choice; 
    
    while(!input.equalsIgnoreCase("n")){
      
  
      rival_choice = rival.generateRoshambo();
      user_choice = user.generateRoshambo();
        
      rival_choice_string = rival_choice.toString();
      user_choice_string = user_choice.toString(); 
      
      output1 = "\n" + rival.getName() + ": " + rival_choice; 
      output2 = "\n" + user.getName() + ": " + user_choice + "\n";
      
      System.out.print(output1 + output2); 
        
      if(rival_choice == user_choice) {
        System.out.print("Tied game. No winner\n"); 
      }else{
        
      switch(rival_choice){
        case ROCK:
          switch(user_choice) {
          case PAPER:
            System.out.println(user.getName() + " wins!");
            wins++;
            break;
          case SCISSORS:
            System.out.println(rival.getName() + " wins!");
            losses++; 
            break;
        }// inner switch ends
          break;
          
        case PAPER:
          switch(user_choice) {
          case ROCK:
            System.out.println(rival.getName() + " wins!");
            losses++;
            break;
          case SCISSORS:
            System.out.println(user.getName() + " wins!");
            wins++;
            break;
        }// inner switch ends
          break;
        
        case SCISSORS:
          switch(user_choice) {
          case ROCK:
            System.out.println(user.getName() + " wins!");
            wins++;
            break;
          case PAPER:
            System.out.println(rival.getName() + " wins!");
            losses++;
            break;
        }// inner switch ends      
          break;
        
        default:
          System.exit(-1);
          break;
        
          }// outer switch 
      }// else 
      
      
      System.out.println("Play again? (y/n):"); 
      System.out.print("\n"); 
      input = Validator.getChar(sc);
      
    }//while ends equalsIgnoreCase("n")
    System.out.println("\n-------------------------------\n");
    System.out.println("wins: " + wins + " Losses: " + losses); 
    System.out.println("\n-------------------------------\n");    
    
  }//main end
  
}//class ends